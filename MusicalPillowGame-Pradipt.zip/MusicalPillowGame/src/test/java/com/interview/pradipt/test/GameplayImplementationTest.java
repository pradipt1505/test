package com.interview.pradipt.test;


import org.junit.Assert;
import org.junit.Test;

import com.interview.pradipt.impl.GameplayImplementation;

public class GameplayImplementationTest {
	
	GameplayImplementation gamePlay = new GameplayImplementation();

	@Test
	public void testCase1() {
		int winner = gamePlay.beginGame(11, 4);
		Assert.assertEquals(9, winner);
	}
	
	@Test
	public void testCase2() {
		int winner = gamePlay.beginGame(5, 2);
		Assert.assertEquals(3, winner);
	}
	
	@Test
	public void testCase3() {
		int winner = gamePlay.beginGame(7, 3);
		Assert.assertEquals(4, winner);
	}

}
