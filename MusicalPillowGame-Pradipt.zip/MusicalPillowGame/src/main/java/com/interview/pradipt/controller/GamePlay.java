/**
 * 
 */
package com.interview.pradipt.controller;

import java.util.Scanner;

import com.interview.pradipt.impl.GameplayImplementation;

/**
 * @author Pradipt Punj Srivastava
 * This class controls the input/output of the programme.
 * This will have two inputs:
 * a) Number of ppl in the game
 * b) Duration of the song in seconds
 * 
 * Output is the number or index of the winner person.
 *
 */
public class GamePlay {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of ppl in the game:");
		int numberOfPpl = sc.nextInt();
		System.out.println("Enter the duration of song(in sec):");
		int songDuration = sc.nextInt();
		GameplayImplementation gameImpl = new GameplayImplementation();
		int winner = gameImpl.beginGame(numberOfPpl, songDuration);
		System.out.println("Winner is player :"+winner);
		sc.close();
	}
	
	
}
