/**
 * 
 */
package com.interview.pradipt.impl;

import com.interview.pradipt.model.Player;

/**
 * @author Pradipt Punj Srivastava :This class has the implementation logic of
 *         the game play. methods : a) beginGame b) playGame c) insertPlayer d)
 *         eliminate
 *
 */
public class GameplayImplementation {

	/**
	 * @param numberOfPpl
	 *            : Number of people in the game.
	 * @param songDuration
	 *            : Duration of the song (in sec)
	 * @return int : Winner of the game.
	 * 
	 *         This method will take inputs from user (entered in Gameplay
	 *         class) and perform further actions.
	 */
	public int beginGame(int numberOfPpl, int songDuration) {
		Player startPlayer = null;
		if(numberOfPpl == 0 || numberOfPpl == 1 || songDuration == 0){
			return 0;
		}
		for (int i = numberOfPpl; i >= 1; i--) {
			// Inserting players in circular linked list.
			startPlayer = insertPlayer(startPlayer, i);
		}
		return playGame(startPlayer, numberOfPpl, songDuration);
	}

	/**
	 * This method will is implemenation logic of the game play, it will iterate
	 * till n-1 ppl in the game and over song duration. As the end of the song
	 * duration 1 player(current player) will be eliminated and the loop will
	 * continue till n-1 ppl in the game.
	 * 
	 * @param startPlayer
	 *            : First player to begin the game.
	 * @param numberOfPpl
	 *            : Number of people in the game.
	 * @param songDuration
	 *            : Duration of the song (in sec)
	 * @return int : Winner of the game
	 */
	private int playGame(Player startPlayer, int numberOfPpl, int songDuration) {
		Player nextPlayer = startPlayer;
		boolean start = true;
		for (int j = 1; j < numberOfPpl; j++) {
			for (int i = 1; i < songDuration; i++) {
				if (start) {
					nextPlayer = startPlayer.getNextPlayer();
					start = false;
				} else {
					nextPlayer = nextPlayer.getNextPlayer();
				}
			}
			nextPlayer = eliminate(nextPlayer, nextPlayer.getPlayerIndex());
		}
		return nextPlayer.getPlayerIndex();
	}

	/**
	 * This method will insert players in circular linked list.
	 * 
	 * @param startPlayer
	 * @param playerIndex
	 * @return startPlayer
	 */
	private Player insertPlayer(Player startPlayer, int playerIndex) {
		//If this is the first player in the list.
		Player newPlayer = new Player();
		newPlayer.setPlayerIndex(playerIndex);
		newPlayer.setNextPlayer(startPlayer);
		if(startPlayer != null){
			Player tempPlayer = startPlayer;
			while(tempPlayer.getNextPlayer() != startPlayer){
				tempPlayer = tempPlayer.getNextPlayer();
			}
			tempPlayer.setNextPlayer(newPlayer);
		}else{
			newPlayer.setNextPlayer(newPlayer);
		}
		return newPlayer;
	}

	/**
	 * This method will delete the player from circular linked list which has to
	 * be eliminated from the game play.
	 * 
	 * @param player
	 *            : Player to be eliminated.
	 * @param playerIndex
	 *            : Index value of player to be eliminated.
	 * @return Player : Next player to the eliminated player.
	 */
	private Player eliminate(Player player, int playerIndex) {
		
		Player currentPlayer = player, prevPlayer = new Player();
		while(currentPlayer.getPlayerIndex() != playerIndex){
			prevPlayer = currentPlayer;
			currentPlayer = currentPlayer.getNextPlayer();
		}
		if (currentPlayer == player) {
			prevPlayer = player.getNextPlayer();
			while(prevPlayer.getNextPlayer() != player){
				prevPlayer = prevPlayer.getNextPlayer();
			}
			player = player.getNextPlayer();
			prevPlayer.setNextPlayer(player);
		} else if (currentPlayer.getNextPlayer() == player) {
			prevPlayer.setNextPlayer(player);
		} else {
			prevPlayer.setNextPlayer(currentPlayer.getNextPlayer());
		}

		return player;
	}
}
